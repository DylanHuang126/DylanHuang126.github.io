1. run TA's preprocessing sample codes to generate datasets and embeddings
2. codes for model training are in floder 'src'. To run codes: python train_ext.py

plot histogram:
import matplotlib.pyplot as plt
plot_rel_loc(all_ext, all_n_sent, bins=20)