#!/usr/bin/env bash

python3.6 eval.py --test_data_path $1 --output_path $2