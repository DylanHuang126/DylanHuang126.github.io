#!/usr/bin/env bash


wget https://www.dropbox.com/s/ohxsayn7t8apet1/QA_8e-6_fz_emb2.pt?dl=1 -O ./model/QA.pt

pip install -r requirements.txt