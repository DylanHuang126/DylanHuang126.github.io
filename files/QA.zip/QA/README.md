install required package:
pip install tensorboardX
pip install matplotlib

train model:
    python3.6 train.py

plot answerable threshold figure:
    run python3.6 thresh.py
    
plot answer length distribution:
    run python3.6 train.py
    

    